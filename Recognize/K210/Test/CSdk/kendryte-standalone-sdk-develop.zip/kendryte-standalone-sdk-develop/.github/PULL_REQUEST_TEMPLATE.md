Fixes #\<GitHub-issue-number\>.

Make sure all boxes are checked (add x inside the brackets) when you submit your contribution, remove this sentence before doing so.

- [ ] I have thoroughly tested my contribution.
- [ ] The code I submitted has no copyright issues.

\<Description of and rational behind this PR\>
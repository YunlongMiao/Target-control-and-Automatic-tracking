#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 

void usart1_init(u32 bound); 
#endif



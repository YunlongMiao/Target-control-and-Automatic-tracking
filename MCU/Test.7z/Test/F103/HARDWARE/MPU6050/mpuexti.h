#ifndef __MPUEXTI_H
#define __MPUEXTI_H

void MPU_exti_init(void);
#endif

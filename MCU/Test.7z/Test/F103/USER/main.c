#include <stm32f10x.h>
#include "delay.h"
#include "sys.h"
#include "Serial.h"
#include "oled.h"
#include "motor.h"
#include "timer.h"
#include "servo.h"
#include "TM1637.h"
#include <pid.h>
//#include "usart.h"	
extern int Angle1,Angle2;
//unsigned int KeyNum;
//float Ang1,Ang2,AngFlag;
//int Angle1,Angle2;

/*
36,23
228,13

108,79
*/
int main()
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	delay_init();
	Serial_Init();
	
	TIM3_PWM_init(20000-1,72-1); //TIM1��pwmģʽ��ʼ��
	motor_gpio_init();
	ServoGpioInit();
	
	
	OLED_Init();			//��ʼ��OLED  
	OLED_Clear(); 

	while(1)
	{
//		steer_to_track(1100,1350);
		TIM_SetCompare2(TIM3,1150);
		delay_ms(1500);
		delay_ms(1500);
		TIM_SetCompare4(TIM3,1400);
		delay_ms(1500);
		delay_ms(1500);
//		ServoXianfu();
//		delay_ms(1000);
//		delay_ms(1000);
//		delay_ms(1000);
//		steer_to_track(1090,1355);
//		delay_ms(1000);
//		delay_ms(1000);
//		delay_ms(1000);
	}

}

//--,+-
//-+,++

	
//	while(1)
//	{
////		steer_to_track(1,1);
//			TIM_SetCompare1(TIM1,20000 - 1170);	//��,��С
//			TIM_SetCompare2(TIM1,20000 - 1360);		//�ϣ���С
////			delay_ms(1500);
////			delay_ms(1500);
//			
////			TIM_SetCompare1(TIM1,20000 - 1274);	//��
////			TIM_SetCompare2(TIM1,20000 - 1540);		//��
////			delay_ms(1500);
////			delay_ms(1500);
//	}

//}




